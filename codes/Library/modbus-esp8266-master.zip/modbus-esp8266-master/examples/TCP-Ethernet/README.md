# W5x00 Example

## Physical connection between ESP32 and W5500

* GPIO23 <--> MOSI
* GPIO19 <--> MISO
* GPIO18 <--> SCLK
* GPIO5  <--> SCS

# Modbus Library for Arduino
### ModbusRTU, ModbusTCP and ModbusTCP Security

(c)2020 [Alexander Emelianov](mailto:a.m.emelianov@gmail.com)

The code in this repo is licensed under the BSD New License. See LICENSE.txt for more info.
